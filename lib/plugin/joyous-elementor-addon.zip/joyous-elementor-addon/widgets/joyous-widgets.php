<?php
/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */


/** 
 * Joyous jewellery widget area
 */
class Joyous_Jewellery_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'joyousjewellerywidget';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Joyous Jewellery', 'joyous-elementor-addon' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-book';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'basic' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

	
		$this->start_controls_section(
			'joyous_jewellery_section',
			[
				'label' => __( 'Joyous Jewellery', 'joyous-elementor-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'joyous_jewellery_heading',
			[
				'label' => __( 'Add Heading', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'JOYOUS JEWELLERY', 'joyous-elementor-addon' ),
			]
		);

		$this->add_control(
			'joyous_jewellery_description',
			[
				'label' => __( 'Add Description', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'lorem ipsum dolloer net', 'joyous-elementor-addon' ),
			]
		);

		$this->add_control(
			'joyous_jewellery_address',
			[
				'label' => __( 'Add Address', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( '1319 Parkview Drive,Washington, USA', 'joyous-elementor-addon' ),
			]
		);

		$this->add_control(
			'joyous_jewellery_phone',
			[
				'label' => __( 'Add Phone', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( '1319 Parkview Drive,Washington, USA', 'joyous-elementor-addon' ),
			]
		);
		$this->add_control(
			'joyous_jewellery_email',
			[
				'label' => __( 'Add Email', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( '1319 Parkview Drive,Washington, USA', 'joyous-elementor-addon' ),
			]
		);

		$this->end_controls_section();

	}


	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		?>
			<div class="ic-widget">
                    <h2><?php echo$settings['joyous_jewellery_heading'];?></h2>
                    <p><?php echo$settings['joyous_jewellery_description'];?> </p>
                    <div class="ic-contact-info">
                        <span class="ic-icon"><i class="icofont icofont-social-google-map"></i></span>
                        <span class="ic-address">
                      <?php echo$settings['joyous_jewellery_address'];?>
                    </span>
                    </div>
                    <div class="ic-contact-info">
                        <span class="ic-icon"><i class="icofont icofont-phone"></i></span>
                        <span class="ic-phone">
                      <a href="tel:7142584350">+<?php echo$settings['joyous_jewellery_phone'];?></a> / 
                      <a href="tel:7142993355">+714-299-3355</a>
                    </span>
                    </div>
                    <div class="ic-contact-info">
                        <span class="ic-icon"><i class="icofont icofont-envelope"></i></span>
                        <span class="ic-email">
                      <a href="mailto:joyousjewellery@gmail.com"><?php echo$settings['joyous_jewellery_email'];?></a>
                    </span>
                    </div>
              </div>
		<?php
	}

	protected function _content_template(){
		?>
			
			<h2>{{{ settings.joyous_jewellery_heading }}}</h2>
			<p>{{{ settings.joyous_jewellery_description }}}</p>
			<span>{{{ settings.joyous_jewellery_address }}}</span>
			<a>{{{ settings.joyous_jewellery_phone }}}</a>
			<a>{{{ settings.joyous_jewellery_email }}}</a>
		<?php
	}

}



/**
 * Joyous social icon widget area
 */ 

class Joyous_Social_Icon_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'joyoussocialicon';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Joyous Social Icon', 'joyous-elementor-addon' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-book';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'basic' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'joyous_social_icon_section',
			[
				'label' => __( 'Joyous Social Icons', 'joyous-elementor-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'joyous_facebook',
			[
				'label' => __( 'Facebook Link', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type'	=> 'url',
				'placeholder' => __( 'social link', 'joyous-elementor-addon' ),
			]
		);

		$this->add_control(
			'joyous_twitter',
			[
				'label' => __( 'Twitter Link', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type'	=> 'url',
				'placeholder' => __( 'social link', 'joyous-elementor-addon' ),
			]
		);
		$this->add_control(
			'joyous_linkedin',
			[
				'label' => __( 'Linkedin Link', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type'	=> 'url',
				'placeholder' => __( 'social link', 'joyous-elementor-addon' ),
			]
		);
		$this->add_control(
			'joyous_google',
			[
				'label' => __( 'Google Link', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type'	=> 'url',
				'placeholder' => __( 'social link', 'joyous-elementor-addon' ),
			]
		);
		$this->add_control(
			'joyous_youtube',
			[
				'label' => __( 'Youtube Link', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type'	=> 'url',
				'placeholder' => __( 'social link', 'joyous-elementor-addon' ),
			]
		);
		$this->add_control(
			'joyous_pinterest',
			[
				'label' => __( 'Pinterest Link', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type'	=> 'url',
				'placeholder' => __( 'social link', 'joyous-elementor-addon' ),
			]
		);
		$this->end_controls_section();

	}


	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		?>
		<div class="ic-social-nav">
                    <ul>
                        <li><a href="<?php echo $settings['joyous_facebook'];?>"><i class="icofont icofont-social-facebook"></i></a></li>
                        <li><a href="<?php echo $settings['joyous_twitter'];?>"><i class="icofont icofont-social-twitter"></i></a></li>
                        <li><a href="<?php echo $settings['joyous_linkedin'];?>"><i class="icofont icofont-brand-linkedin"></i></a></li>
                        <li><a href="<?php echo $settings['joyous_google'];?>"><i class="icofont icofont-social-google-plus"></i></a></li>
                        <li><a href="<?php echo $settings['joyous_youtube'];?>"><i class="icofont icofont-brand-youtube"></i></a></li>
                        <li><a href="<?php echo $settings['joyous_pinterest'];?>"><i class="icofont icofont-social-pinterest"></i></a></li>
                    </ul>
                </div>
		<?php
	}

	protected function _content_template(){
		?>
			<a>{{{ settings.joyous_facebook }}}</a>
			<a>{{{ settings.joyous_twitter }}}</a>
			<a>{{{ settings.joyous_linkedin }}}</a>
			<a>{{{ settings.joyous_google }}}</a>
			<a>{{{ settings.joyous_youtube }}}</a>
			<a>{{{ settings.joyous_pinterest }}}</a>
		<?php
	}

}


/**
 * Payment method images widget area
 */ 

class Joyous_payment_images_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'joyouspaymentimages';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Joyous Payment Methods Images', 'joyous-elementor-addon' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-book';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'basic' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'joyous_payment_images_section',
			[
				'label' => __( 'Payment Method Image', 'joyous-elementor-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'joyous_payment_method_image',
			[
				'label' => __( 'Add Payment Method Image', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		?>
			<div class="ic-payment-method ic-mcol">
                    <h3>Payment method</h3>
                    
                    <?php echo wp_get_attachment_image( $settings['joyous_payment_method_image']['id'],'full' );?>
                    
                </div>
		<?php
	}

	protected function _content_template(){
		?>
			<img src="{{{ settings.joyous_payment_method_image.url }}}">
			
		<?php
	}

}

/**
 * Joyous slider widget area
 */ 
class Joyous_Slider_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'joyousslider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Joyous Slider', 'joyous-elementor-addon' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-book';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'basic' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'joyous_slider_section',
			[
				'label' => __( 'Joyous Slider', 'joyous-elementor-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'joyous_slider_image',
			[
				'label' => __( 'Add Slider Image', 'joyous-elementor-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section();

	}

	
	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display(); ?>
		<section class="ic-slider swiper-container ic-mb">
			<div class="ic-slider-bg">
				
				<?php echo wp_get_attachment_image($settings['joyous_slider_image']['id'],'full')?>
			</div>
		</section>
	<?php }

	protected function _content_template(){
		?>
			<img src="{{{ settings.joyous_slider_image.url }}}">
		<?php
	}

}





